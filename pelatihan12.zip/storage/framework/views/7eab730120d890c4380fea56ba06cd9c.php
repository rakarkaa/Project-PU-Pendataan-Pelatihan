

<?php $__env->startSection('konten'); ?>                    
                    <!-- Content Row -->
                    <div class="row">

                   <!-- Content Row --> 
                    <div class="container-sm shadow-sm p-3 mb-5 bg-body rounded">
                    <h5 class="font-weight-bold text-gray-800">Input Data Pelatihan Kepemimpinan Administrator</h5><br> 
                   <form>
                        <div class="mb-3">
                            <label for="" class="form-label">Nama</label>
                            <input type="email" class="form-control" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Jabatan</label>
                            <input type="password" class="form-control" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Unit Divisi</label>
                            <input type="password" class="form-control" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Tanggal Mulai</label>
                            <input type="password" class="form-control" id="">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Tanggal Akhir</label>
                            <input type="password" class="form-control" id="">
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>

                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pelatihan12\resources\views/pages/administrator.blade.php ENDPATH**/ ?>