

<?php $__env->startSection('konten'); ?>
            <!-- Content Row -->
            <div class="row">
                <div class="container-sm shadow-sm p-3 mb-5 bg-body rounded">
                    <div class="card">
                        <div class="card-header">Daftar Data Pelatihan</div>

                        <?php if(session('message')): ?>
                        <div class="alert alert-primary"><?php echo e(session('message')); ?></div>
                        <?php endif; ?>

                        <div class="d-grid gap-2 col-12 mx-auto"><br>
                        <a href="<?php echo e(route('fungsional.create')); ?>" class="btn btn-primary" type="button">Tambah Data</a>
                        </div><br>
                        
                        <div class="card-body table-responsive text-center">
                            <table id ="fungsional" class="table table-striped table-bordered">
                                <thead>
                                    <tr class="text-nowrap">
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>NIP</th>
                                        <th>Tempat Lahir</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Jenis Kelamin</th>

                                        <th>Jabatan</th>
                                        <th>Unit Kerja</th>
                                        <th>Unit Organisasi</th>
                                        <th>Instansi</th>

                                        <th>Usulan Pelatihan</th>
                                        <th>Penyelenggara / Mekanisme</th>
                                        <th>Pelaksanaan</th>
                                        <th>Jenis Kepesertaan</th>

                                        <th>Kehadiran</th>
                                        <th>Alasan Tidak Hadir</th>

                                        <th>Nilai Akhir</th>
                                        <th>Predikat</th>
                                        <th>Status</th>
                                        <th>Keterangan</th>

                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-nowrap">
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->nip); ?></td>
                                        <td><?php echo e($item->tempat_lahir); ?></td>
                                        <td><?php echo e($item->tanggal_lahir); ?></td>
                                        <td><?php echo e($item->jenis_kelamin); ?></td>

                                        <td><?php echo e($item->jabatan); ?></td>
                                        <td><?php echo e($item->unit_kerja); ?></td>
                                        <td><?php echo e($item->unit_organisasi); ?></td>
                                        <td><?php echo e($item->instansi); ?></td>

                                        <td><?php echo e($item->usulan_pelatihan); ?></td>
                                        <td><?php echo e($item->penyelenggara_mekanisme); ?></td>
                                        <td><?php echo e($item->pelaksanaan); ?></td>
                                        <td><?php echo e($item->jenis_kepesertaan); ?></td>

                                        <td><?php echo e($item->kehadiran); ?></td>
                                        <td><?php echo e($item->alasan_tidak_hadir); ?></td>

                                        <td><?php echo e($item->nilai_akhir); ?></td>
                                        <td><?php echo e($item->predikat); ?></td>
                                        <td><?php echo e($item->status); ?></td>
                                        <td><?php echo e($item->keterangan); ?></td>
                                    <td>
                                        <div class="d-flex justify-content-center gap-2">
                                            <!-- <button type="button" class="btn btn-danger">Hapus</button> -->
                                            <button type="button" class="btn btn-danger btn-sm mr-2" data-toggle="modal" data-target="#modalHapus_<?php echo e($item->id); ?>">
                                                Hapus Data
                                            </button>
                                            <a href="<?php echo e(route('fungsional.edit', $item->id)); ?>" class="btn btn-warning btn-sm">edit</a>
                                        </div>
                                    </td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal -->
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="modalHapus_<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="modalHapusLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <form action="/fungsional/<?php echo e($item->id); ?>" method="POST">
                        <div class="modal-content">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Konfirmasi</h1>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                Apakah Anda Yakin Menghapus Nama <?php echo e($item->nama); ?>?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">batal</button>
                                <button type="submit" class="btn btn-danger">Hapus Data</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End of Main Content -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pelatihan12\resources\views/fungsional/show.blade.php ENDPATH**/ ?>