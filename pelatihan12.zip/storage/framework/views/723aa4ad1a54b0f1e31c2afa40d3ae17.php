

<?php $__env->startSection('konten'); ?>
            <!-- Content Row -->
            <div class="row">
                <div class="container-sm shadow-sm p-3 mb-5 bg-body rounded">
                    <div class="card">
                        <div class="card-header">Daftar Data Pelatihan Kepemimpinan</div>

                        <?php if(session('message')): ?>
                        <div class="alert alert-primary"><?php echo e(session('message')); ?></div>
                        <?php endif; ?>

                        <div class="d-grid gap-2 col-12 mx-auto"><br>
                        <a href="/kepemimpinan/create" class="btn btn-primary" type="button">Tambah Data</a>
                        </div>
                        
                        <div class="card-body">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Jabatan</th>
                                    <th scope="col">Unit</th>
                                    <th scope="col">Tanggal Mulai</th>
                                    <th scope="col">Tanggal Akhir</th>
                                    <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data_kepemimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->jabatan); ?></td>
                                    <td><?php echo e($item->unit); ?></td>
                                    <td><?php echo e($item->tgl_mulai); ?></td>
                                    <td><?php echo e($item->tgl_akhir); ?></td>
                                    <td>
                                        <!-- <button type="button" class="btn btn-danger">Hapus</button> -->
                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modalHapus_<?php echo e($item->id_kepemimpinan); ?>">
                                            Hapus Data
                                        </button>
                                        <a href="/kepemimpinan/<?php echo e($item->id_kepemimpinan); ?>/edit" class="btn btn-warning">edit</a>
                                    </td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal -->
            <?php $__currentLoopData = $data_kepemimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="modalHapus_<?php echo e($item->id_kepemimpinan); ?>" tabindex="-1" aria-labelledby="modalHapusLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <form action="/kepemimpinan/<?php echo e($item->id_kepemimpinan); ?>" method="POST">
                        <div class="modal-content">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Konfirmasi</h1>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                Apakah Anda Yakin Menghapus Nama <?php echo e($item->nama); ?>?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">batal</button>
                                <button type="submit" class="btn btn-danger">Hapus Data</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pelatihan12\resources\views/kepemimpinan/show.blade.php ENDPATH**/ ?>