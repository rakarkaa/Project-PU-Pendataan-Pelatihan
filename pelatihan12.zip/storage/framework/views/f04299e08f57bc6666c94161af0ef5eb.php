<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Laravel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
            text-align: center;
            padding-top: 100px;
        }
        .box {
            background: white;
            padding: 40px;
            border-radius: 10px;
            width: 400px;
            margin: 0 auto;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2563eb;
        }
        p {
            color: #555;
        }
    </style>
</head>
<body>

    <div class="box">
        <h1>Selamat Datang</h1>
        <p>Anda berhasil menggunakan Framework Laravel 🎉</p>
    </div>

</body>
</html>
<?php /**PATH C:\laragon\www\pelatihan12\resources\views/welcome.blade.php ENDPATH**/ ?>