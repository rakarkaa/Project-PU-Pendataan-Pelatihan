

<?php $__env->startSection('konten'); ?>
               <!-- Content Row -->
                    <div class="row">


                <!-- Table -->
                    <div class="container-sm shadow-sm p-3 mb-5 bg-body rounded">
                    <div class="card">
                    <div class="card-header">Daftar Nama</div>
                    <div class="d-grid gap-2 col-12 mx-auto"><br>
                    <a href="/kepemimpinan/tambah" class="btn btn-primary" type="button">Tambah Data</a>
                    </div>
                    <div class="card-body">
                    <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Jabatan</th>
                        <th scope="col">Unit</th>
                        <th scope="col">Tanggal Mulai</th>
                        <th scope="col">Tanggal Akhir</th>
                        <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        </tr>
                        <tr>
                        <th scope="row">2</th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        </tr>
                        <tr>
                        <th scope="row">3</th>
                        <td>Larry the Bird</td>
                        <td>@twitter</td>
                        <td>@twitter</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        </tr>
                        
                    </tbody>
                    </table>

                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pelatihan12\resources\views/pages/kepemimpinan.blade.php ENDPATH**/ ?>