<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang</title>
</head>
<body>
    <h1>About</h1>
    <p>Kami senang Anda ada di sini.</p>
</body>
</html>

<?php /**PATH C:\laragon\www\pelatihan12\resources\views/pages/about.blade.php ENDPATH**/ ?>