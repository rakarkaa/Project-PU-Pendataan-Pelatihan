

<?php $__env->startSection('konten'); ?>
               <!-- Content Row -->
                    <div class="row">

                   <!-- Content Row --> 
                    <div class="container-sm shadow-sm p-3 mb-5 bg-body rounded">
                    <h5 class="font-weight-bold text-gray-800">Input Data Pelatihan Kepemimpinan Nasionaal Tingkat 2</h5>
                    <div class="card-body">
                   <form action="/pengawas" method="POST">
                    <?php echo csrf_field(); ?>
                         <div class="mb-3">
                            <label class="form-label">Nama</label>
                            <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama')); ?>">
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Jabatan</label>
                            <input type="text" name="jabatan" class="form-control" value="<?php echo e(old('jabatan')); ?>">
                        </div>
                            <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                        
                        <div class="mb-3">
                                <label for="" class="form-label">Unit Divisi</label>
                                <input type="text" name="unit" class="form-control" value="<?php echo e(old('unit')); ?>">
                        </div>
                            <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                       
                        <div class="mb-3">
                            <label for="" class="form-label">Tanggal Masuk</label>
                            <input type="date" name="tgl_mulai" class="form-control" value="<?php echo e(old('tgl_mulai')); ?>">
                        </div>
                            <?php $__errorArgs = ['tgl_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="mb-3">
                            <label for="" class="form-label">Tanggal Akhir</label>
                            <input type="date" name="tgl_akhir" class="form-control" value="<?php echo e(old('tgl_akhir')); ?>">
                        </div>
                            <?php $__errorArgs = ['tgl_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="/administrator" class="btn btn-secondary" type="button">Kembali</a>
                        </form>
                        
                    </div>

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pelatihan12\resources\views/pengawas/add.blade.php ENDPATH**/ ?>