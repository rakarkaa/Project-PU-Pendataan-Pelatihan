

<?php $__env->startSection('konten'); ?>
               <!-- Content Row -->
                    <div class="row">

                   <!-- Content Row --> 
                    <div class="container-sm shadow-sm p-3 mb-5 bg-body rounded">
                    <h5 class="font-weight-bold text-gray-800">Edit Data Pelatihan Kepemimpinan Nasional Tingkat 2</h5>
                    <div class="card-body">
                   <form action="/administrator/<?php echo e($data->id); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Nama</label>
                            <input type="text" name="nama" class="form-control" value="<?php echo e($data->nama); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Jabatan</label>
                            <input type="text" name="jabatan" class="form-control" value="<?php echo e($data->jabatan); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Unit Divisi</label>
                            <input type="text" name="unit" class="form-control" value="<?php echo e($data->unit); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Tanggal Mulai</label>
                            <input type="date" name="tgl_mulai" class="form-control" value="<?php echo e(old('tgl_mulai', $data->tgl_mulai)); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Tanggal Akhir</label>
                            <input type="date" name="tgl_akhir" class="form-control" value="<?php echo e(old('tgl_akhir', $data->tgl_akhir)); ?>">

                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="/administrator" class="btn btn-secondary" type="button">Kembali</a>
                        </form>
                        
                    </div>

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pelatihan12\resources\views/administrator/edit.blade.php ENDPATH**/ ?>